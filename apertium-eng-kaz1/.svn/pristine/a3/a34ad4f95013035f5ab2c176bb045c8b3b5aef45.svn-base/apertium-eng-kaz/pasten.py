#!/usr/bin/python3
 
import sys;
 
for line in sys.stdin.readlines(): #{
        row = line.strip('\n');
        for x in range(0, int(sys.argv[1])): #{
                sys.stdout.write(row);
                sys.stdout.write('\t');
        #}
        sys.stdout.write('\n');
#}
