#!/bin/sh

cat