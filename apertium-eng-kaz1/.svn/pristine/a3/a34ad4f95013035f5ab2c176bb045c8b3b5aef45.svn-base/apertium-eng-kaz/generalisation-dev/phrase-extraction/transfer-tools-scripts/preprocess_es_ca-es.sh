#!/bin/sh

sed -re "s/[\^]deber<vbmod>/^deber<vblex>/g"
