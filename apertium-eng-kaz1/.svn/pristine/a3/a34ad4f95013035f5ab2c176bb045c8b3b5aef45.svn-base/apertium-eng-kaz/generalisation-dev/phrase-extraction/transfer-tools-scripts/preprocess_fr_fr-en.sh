#!/bin/sh

cat 
