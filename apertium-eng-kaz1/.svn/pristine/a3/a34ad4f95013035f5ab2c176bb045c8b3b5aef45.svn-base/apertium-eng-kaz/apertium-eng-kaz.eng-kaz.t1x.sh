#!/bin/sh
mogrify -crop 1000x803+0+0 apertium-eng-kaz.eng-kaz.t1x.png
exit 0
