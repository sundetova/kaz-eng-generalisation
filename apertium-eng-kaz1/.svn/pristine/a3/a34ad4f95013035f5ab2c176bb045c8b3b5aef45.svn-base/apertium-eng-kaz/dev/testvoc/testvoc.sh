if [[ $1 = "eng-kaz" ]]; then
echo "==English->Kazakh===========================";
bash inconsistency.sh eng-kaz > /tmp/eng-kaz.testvoc; bash inconsistency-summary.sh /tmp/eng-kaz.testvoc eng-kaz
echo ""

fi
