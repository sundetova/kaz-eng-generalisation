hfst-strings2fst  | hfst-compose-intersect -2 lat-kaz.hfst  | hfst-fst2strings 
